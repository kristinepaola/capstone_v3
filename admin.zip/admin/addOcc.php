<html>
	<form method="POST" action="insertOcc.php">
		Occupation Name: <input type="text" name="occ">
		<input type="submit" value="Submit">
	</form>
</html>